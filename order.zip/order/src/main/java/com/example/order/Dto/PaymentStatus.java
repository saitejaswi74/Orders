package com.example.order.Dto;


public enum PaymentStatus
{
    PAID,PENDING;
}

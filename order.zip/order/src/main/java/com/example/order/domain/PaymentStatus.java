package com.example.order.domain;


public enum PaymentStatus
{
    PAID,PENDING;
}
